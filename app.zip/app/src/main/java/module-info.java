module com.mycompany.app {
    requires javafx.controls;
    exports com.mycompany.app;
}
